<?php

class COST_api {

    public function __construct($atts = array())
    {

    }
    public function request($json, $action = array(
        "type" => "postEvent"
    ))
    {
        $setting = get_option('Elios_settings');
        if($setting === false || $setting ===""){
            $setting = '{"user":"","password":"","host":""}';
        }
        $setting = json_decode($setting,true);
        $action['data'] = $json;
        $action['key'] = $setting['key'];
        $action['host'] = $setting['host'];
        $action['cms'] = "wordpress";
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => COST_api,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($action),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
            ),
        ));
        
        $response = curl_exec($curl);

        curl_close($curl);

        return $response;        
    }
}